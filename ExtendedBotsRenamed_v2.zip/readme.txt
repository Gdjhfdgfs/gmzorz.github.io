Custom bot names for editors. The [RED] Clantag has been removed as well.

ExtendedBots.Red32n goes in Redacted\Plugins
Check all bot names: https://ghostbin.com/paste/g64t2

Credits
Deity 
